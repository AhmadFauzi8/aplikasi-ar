package com.fauzi.arapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import java.io.InputStreamReader

class MateriActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var materiAdapter: MateriAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_materi)

        setupToolbar()

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Load materi data from JSON
        val materiList = loadMateriFromJson()

        if (materiList != null) {
            materiAdapter = MateriAdapter(materiList)
            recyclerView.adapter = materiAdapter
        }

        // Handling item click in the adapter
        materiAdapter.setOnItemClickListener { title ->
            // Open the DetailMateriActivity and pass the title
            val intent = Intent(this, DetailMateriActivity::class.java)
            intent.putExtra("title", title)
            startActivity(intent)
        }
    }

    private fun setupToolbar() {
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    // Function to load materi data from JSON file
    private fun loadMateriFromJson(): List<Pair<String, String>>? {
        try {
            // Load JSON file from assets
            val inputStream = assets.open("data/materi_baru.json")
            val reader = InputStreamReader(inputStream)
            val materiData = Gson().fromJson(reader, Array<MateriItem>::class.java)
            return materiData?.map { it.title to it.description }
        } catch (e: Exception) {
            Log.e("MateriActivity", "Error loading JSON", e)
            return null
        }
    }
}
