package com.fauzi.arapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import java.io.InputStreamReader

class DetailMateriActivity : AppCompatActivity() {

    private lateinit var nextButton: Button
    private lateinit var arButton: Button
    private lateinit var materiTitle: TextView
    private lateinit var materiDescription: TextView
    private lateinit var materiImage: ImageView
    private var materiData: Array<MateriItem>? = null
    private var currentIndex = 0
    private var currentTitle: String? = null
    private lateinit var materiImagesRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_materi)

        setupToolbar()

        nextButton = findViewById(R.id.nextButton)
        arButton = findViewById(R.id.arButton)
        materiTitle = findViewById(R.id.materiTitle)
        materiDescription = findViewById(R.id.materiDescription)
        materiImagesRecyclerView = findViewById(R.id.materiImagesRecyclerView)

        val title = intent.getStringExtra("title")
        currentTitle = title

        // Load materi detail from JSON based on the title
        materiData = loadMateriFromJson()

        // Display the first material based on the title
        displayMateri(title)

        // Set up the Next button
        nextButton.setOnClickListener {
            showNextMateri()
        }

        // Set up the AR button
        arButton.setOnClickListener {
            showTrigonometryAR()
        }
    }

    private fun displayMateri(title: String?) {
        materiData?.let { materiList ->
            val materiItem = materiList.find { it.title == title }
            materiItem?.let {
                materiTitle.text = it.title
                materiDescription.text = it.description

                val adapter = MateriImagesAdapter(this, it.images.toList())
                materiImagesRecyclerView.layoutManager =
                    androidx.recyclerview.widget.LinearLayoutManager(this, RecyclerView.VERTICAL, false)
                materiImagesRecyclerView.adapter = adapter
            }
        }
    }
    private fun setupToolbar() {
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun loadMateriFromJson(): Array<MateriItem>? {
        try {
            val inputStream = assets.open("data/detail_materi_baru.json")
            val reader = InputStreamReader(inputStream)
            return Gson().fromJson(reader, Array<MateriItem>::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
//    private fun displayMateri(title: String?) {
//        materiData?.let { materiList ->
//            // Find the material that matches the title
//            val materiItem = materiList.find { it.title == title }
//            materiItem?.let {
//                materiTitle.text = it.title
//                materiDescription.text = it.description
//                Log.d("DetailMateriActivity", "Title: ${it.title}, Description: ${it.description}")
//
//                // Load the image from assets/img
//                try {
//                    val inputStream = assets.open("img/${it.image}")
//                    val drawable = Drawable.createFromStream(inputStream, null)
//                    materiImage.setImageDrawable(drawable)
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                    // Handle missing or invalid image
////                    materiImage.setImageResource(R.drawable.placeholder_image) // Use a placeholder image
//                }
//            }
//        }
//    }

    private fun showNextMateri() {
        materiData?.let { materiList ->
            currentIndex = materiList.indexOfFirst { it.title == currentTitle }

            if (currentIndex != -1 && currentIndex < materiList.size - 1) {
                val nextMateri = materiList[currentIndex + 1]
                materiTitle.text = nextMateri.title
                materiDescription.text = nextMateri.description
                currentTitle = nextMateri.title
                val adapter = MateriImagesAdapter(this, nextMateri.images.toList())
                materiImagesRecyclerView.layoutManager =
                    androidx.recyclerview.widget.LinearLayoutManager(this, RecyclerView.VERTICAL, false)
                materiImagesRecyclerView.adapter = adapter
            } else {
                // If it's the last item, you can show a message or disable the button
                nextButton.isEnabled = false
                nextButton.text = "No more materials"
            }
        }
    }

    private fun showTrigonometryAR() {
        // This is where you would launch an AR activity, e.g., using ARCore or any AR library.
        // For now, we'll just show a toast or move to another activity.
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}
