package com.fauzi.arapp

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class MateriImagesAdapter(
    private val context: Context,
    private val imageList: List<String>
) : RecyclerView.Adapter<MateriImagesAdapter.ImageViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_image, parent, false)
        return ImageViewHolder(view)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val imageName = imageList[position]
        try {
            Log.d("MateriImagesAdapter", "Gambar ke-$position: $imageName")
            val inputStream = context.assets.open("img/$imageName")
            val drawable = Drawable.createFromStream(inputStream, null)
            holder.imageView.setImageDrawable(drawable)
        } catch (e: Exception) {
            e.printStackTrace()
          Log.e("MateriImagesAdapter", "Error loading image: $imageName", e)
        }
    }

    override fun getItemCount(): Int = imageList.size

    class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
    }
}