package com.fauzi.arapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

import kotlinx.coroutines.*

class HomeActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Inisialisasi tombol kartu dari layout
        val buttonMateri = findViewById<MaterialCardView>(R.id.button_materi)
        val buttonQuiz = findViewById<MaterialCardView>(R.id.button_quiz)

        // Arahkan ke MateriActivity saat tombol materi diklik
        buttonMateri.setOnClickListener {
            val intent = Intent(this, MateriActivity::class.java)
            startActivity(intent)
        }

        // Arahkan ke QuizActivity saat tombol quiz diklik
        buttonQuiz.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            startActivity(intent)
        }
    }

}