package com.fauzi.arapp

import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.fauzi.arapp.databinding.ActivityQuizBinding

class QuizActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuizBinding

    private val questions = listOf(
        "Berapa nilai sinus dari 45 derajat?",
        "Berapa nilai tangen dari 30 derajat?",
        "Berapa nilai kosinus dari 60 derajat?",
        "Berapa nilai sinus dari 90 derajat?",
        "Berapa nilai tangen dari 0 derajat?",
        "Berapa nilai kosinus dari 90 derajat?",
        "Berapa nilai sinus dari 0 derajat?",
        "Berapa nilai kosinus dari 0 derajat?",
        "Berapa nilai tangen dari 45 derajat?",
        "Berapa nilai sinus dari 30 derajat?",
        "Berapa nilai kosinus dari 45 derajat?",
        "Berapa nilai tangen dari 60 derajat?",
        "Berapa nilai sinus dari 60 derajat?",
        "Berapa nilai kosinus dari 30 derajat?",
        "Berapa nilai tangen dari 90 derajat?",
        "Berapa nilai kosinus dari 180 derajat?",
        "Berapa nilai sinus dari 180 derajat?",
        "Berapa nilai sinus dari 270 derajat?",
        "Berapa nilai kosinus dari 270 derajat?",
        "Berapa nilai tangen dari 180 derajat?"
    )

    private val answers = listOf(
        listOf("0.707", "1", "0.5", "0.866"),
        listOf("0.577", "1", "0", "0.707"),
        listOf("0.5", "1", "0.866", "0"),
        listOf("0", "1", "0.5", "0.707"),
        listOf("0", "1", "0.5", "0.707"),
        listOf("0", "1", "0.5", "0"),
        listOf("0", "1", "0.5", "0.707"),
        listOf("1", "0", "0.5", "0.707"),
        listOf("1", "0", "1", "0.707"),
        listOf("0.5", "1", "0", "0.707"),
        listOf("0.707", "1", "0.5", "0.866"),
        listOf("1.732", "1", "0", "0.707"),
        listOf("0.866", "0", "0.5", "1"),
        listOf("0.866", "1", "0.707", "0"),
        listOf("2", "0", "1", "0.707"),
        listOf("-1", "0", "1", "0.707"),
        listOf("0", "-1", "0.5", "0.707"),
        listOf("-1", "0", "0.5", "-0.707"),
        listOf("0", "-1", "1", "0.707"),
        listOf("0", "1", "2", "0.577")
    )

    private val correctAnswers = listOf(
        0, 0, 2, 1,
        0, 2, 0, 0,
        2, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 1, 0
    )

    private var currentQuestionIndex = 0
    private var score = 0
    private val questionOrder = (questions.indices).shuffled()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        loadQuestion()

        binding.option1.setOnClickListener { checkAnswer(0) }
        binding.option2.setOnClickListener { checkAnswer(1) }
        binding.option3.setOnClickListener { checkAnswer(2) }
        binding.option4.setOnClickListener { checkAnswer(3) }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun loadQuestion() {
        if (currentQuestionIndex < questions.size) {
            val questionIndex = questionOrder[currentQuestionIndex]
            binding.questionText.text = questions[questionIndex]
            val options = answers[questionIndex]
            binding.option1.text = options[0]
            binding.option2.text = options[1]
            binding.option3.text = options[2]
            binding.option4.text = options[3]

            // Update progress
            binding.progressBar.progress = ((currentQuestionIndex + 1) * 100) / questions.size

            // Update score dynamically
            binding.scoreText.text = "Nilai: $score Point"
        }
    }

    private fun checkAnswer(answerIndex: Int) {
        val questionIndex = questionOrder[currentQuestionIndex]
        if (answerIndex == correctAnswers[questionIndex]) {
            score += 10
            Toast.makeText(this, "Benar!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Salah!", Toast.LENGTH_SHORT).show()
        }

        currentQuestionIndex++
        if (currentQuestionIndex < questions.size) {
            loadQuestion()
        } else {
            showCompletionPopup()
        }
    }

    private fun showCompletionPopup() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_quiz_completion, null)
        val dialogBuilder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setTitle("Kuis Selesai!")
            .setMessage("Skor Akhir: $score")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                finish()
            }

        val imageView = dialogView.findViewById<ImageView>(R.id.completion_image)
        imageView.setImageResource(R.drawable.illustrator)

        dialogBuilder.create().show()
    }
}