package com.fauzi.arapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MateriAdapter(private val materiList: List<Pair<String, String>>) : RecyclerView.Adapter<MateriAdapter.MateriViewHolder>() {

    private var itemClickListener: ((String) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MateriViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_materi, parent, false)
        return MateriViewHolder(view)
    }

    override fun onBindViewHolder(holder: MateriViewHolder, position: Int) {
        holder.bind(materiList[position])
    }

    override fun getItemCount(): Int = materiList.size

    // Function to handle item clicks
    fun setOnItemClickListener(listener: (String) -> Unit) {
        itemClickListener = listener
    }

    inner class MateriViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.progress_title)
        private val subtitleTextView: TextView = itemView.findViewById(R.id.progress_description)

        fun bind(materi: Pair<String, String>) {
            titleTextView.text = materi.first
            subtitleTextView.text = materi.second

            // Set click listener for the item
            itemView.setOnClickListener {
                itemClickListener?.invoke(materi.first)
            }
        }
    }
}
