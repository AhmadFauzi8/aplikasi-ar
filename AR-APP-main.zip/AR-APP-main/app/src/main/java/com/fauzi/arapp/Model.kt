package com.fauzi.arapp


data class Furniture(val name: String, val imageResId: Int, val desc: String)

data class Materi(
    val title: String,
    val description: String
)

data class MateriItem(
    val title: String,
    val description: String,
    val images: Array<String>,
)
